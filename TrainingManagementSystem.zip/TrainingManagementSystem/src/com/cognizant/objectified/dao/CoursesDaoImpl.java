package com.cognizant.objectified.dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;


import com.cognizant.objectified.model.Courses;

public class CoursesDaoImpl extends CoursesDao{
	
	public String addCourses(String name, String mode,String desc) {
		String msg="";
		try {
			courses.setName(name);
			courses.setMode(mode);
			courses.setDesc(desc);
			em = getEntityManager();
			em.getTransaction().begin();
			em.persist(courses);
			em.getTransaction().commit();
			msg="success";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			closeEntityManager();
			
		}
		
		return msg;
		
	}
		

	
	public  String deleteCourses(int id) {
		String message = null;
		Courses coursespojo = null;
		try {
			/* Remove entity */
			//courses.setId(id);
			em = getEntityManager();
			em.getTransaction().begin();
			coursespojo=em.find(Courses.class, id);
			em.remove(coursespojo);
			em.getTransaction().commit();
			message="success";

		} catch (Exception e) {
			message="";
			
		}finally {
			closeEntityManager();
		}
		return message;
		
	}

	
	public List<Courses> searchCourses() {
		List<Courses> courseList  = new ArrayList<>();
		try {
			/* retrive entity */
			em = getEntityManager();
			em.getTransaction().begin();
			Query query = em.createQuery("from Courses");
			courseList = (List<Courses>)query.getResultList();
			em.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeEntityManager();
		}
		return courseList;
	}


	
	public String editCourses(Courses courses) {
		String message = null;
		Courses coursespojo = null;
		try {
			/* Update entity */
			em = getEntityManager();
			em.getTransaction().begin();
			coursespojo = em.find(Courses.class, courses.getId());
			coursespojo.setName(courses.getName());
			coursespojo.setDesc(courses.getDesc());
			em.getTransaction().commit();
			message="success";
		} catch (Exception e) {
			//e.printStackTrace();
			message="";
		}finally {
			closeEntityManager();
		}
		//return employeePojo;
		return message;
	}
		
	
}
