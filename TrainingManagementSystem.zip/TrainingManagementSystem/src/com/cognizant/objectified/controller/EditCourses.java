package com.cognizant.objectified.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.objectified.dao.CoursesDaoImpl;
import com.cognizant.objectified.model.Courses;

/**
 * Servlet implementation class EditCourses
 */
@WebServlet("/EditCourses")
public class EditCourses extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 CoursesDaoImpl dao = new CoursesDaoImpl();  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditCourses() {
        super();
        
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id1"));
		String name=request.getParameter("id2");
		String desc=request.getParameter("id3");
		//Courses course=new Courses(id, name, mode);
		String msg="";
		Courses courses = new Courses(id,name,desc);
		msg=dao.editCourses(courses);
		pw.write(msg);
		//RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
		//rd.include(request, response);
	}

}
