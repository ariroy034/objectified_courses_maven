package com.cognizant.objectified.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.objectified.dao.CoursesDaoImpl;
import com.cognizant.objectified.model.Courses;

/**
 * Servlet implementation class DeleteCourse
 */
@WebServlet("/DeleteCourse")
public class DeleteCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public DeleteCourse() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter(); 
		int id = Integer.parseInt(request.getParameter("id"));
		 CoursesDaoImpl c=new CoursesDaoImpl();
         System.out.println(id);
		 String p=c.deleteCourses(id);
		 if(p.equalsIgnoreCase("Success")){
	     RequestDispatcher dispatcher = request.getRequestDispatcher("Courses.jsp");
		 request.setAttribute("courseid", id);
		 dispatcher.forward(request, response);
		 pw.write("Success");
		 }
		 else
			 pw.write("");
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
		}

	

}
